GOLD MOTION - CUSTOM EFFECTS PACK
==================================

77 ready-to-import custom effects (68 originals + 9 Pro examples), built on the Gold Motion /
Alight Motion custom effect schema.

WHAT IS IN THE BOX
------------------

Color and Grade (10)
  - Teal and Orange  [teal_orange.xml]
  - Bleach Bypass  [bleach_bypass.xml]
  - Mono Contrast  [mono_contrast.xml]
  - Duotone Mapper  [duotone.xml]
  - Warm Film  [warm_film.xml]
  - Cold Steel  [cold_steel.xml]
  - Luma Curve  [luma_curve.xml]
  - Channel Mixer  [channel_mixer.xml]
  - Selective Saturation  [selective_sat.xml]
  - Faded Matte  [fade_matte.xml]

Blur and Focus (6)
  - Radial Focus  [radial_focus.xml]
  - Tilt Shift  [tilt_shift.xml]
  - Zoom Blur  [zoom_blur.xml]
  - Directional Blur  [directional_blur.xml]
  - Soft Focus  [soft_focus.xml]
  - Unsharp Mask  [unsharp.xml]

Distort and Warp (8)
  - Ripple  [ripple.xml]
  - Twirl  [twirl.xml]
  - Bulge and Pinch  [bulge.xml]
  - Wave Warp  [wave_warp.xml]
  - Kaleidoscope  [kaleidoscope.xml]
  - Mirror Split  [mirror_split.xml]
  - Fisheye  [fisheye.xml]
  - Turbulence Displace  [turbulence.xml]

Glitch and Digital (8)
  - RGB Split  [rgb_split.xml]
  - Scanlines  [scanlines.xml]
  - Pixelate  [pixelate.xml]
  - Block Glitch  [block_glitch.xml]
  - VHS Tape  [vhs.xml]
  - Bit Crush  [bitcrush.xml]
  - Ordered Dither  [dither.xml]
  - CRT Screen  [crt.xml]

Light and Glow (8)
  - Bloom  [bloom.xml]
  - Soft Glow  [soft_glow.xml]
  - God Rays  [god_rays.xml]
  - Light Sweep  [light_sweep.xml]
  - Halation  [halation.xml]
  - Star Glow  [star_glow.xml]
  - Anamorphic Streak  [anamorphic.xml]
  - Vignette Pro  [vignette_pro.xml]

Stylize and Art (8)
  - Posterize  [posterize.xml]
  - Halftone  [halftone.xml]
  - Comic Ink  [comic_ink.xml]
  - Pencil Sketch  [pencil.xml]
  - Watercolor  [watercolor.xml]
  - Emboss  [emboss.xml]
  - Stained Glass  [stained_glass.xml]
  - Mosaic Tiles  [mosaic.xml]

Procedural (8)
  - Plasma Field  [plasma.xml]
  - Starfield  [starfield.xml]
  - Noise Field  [noise_field.xml]
  - Grid Lines  [grid_lines.xml]
  - Voronoi Cells  [voronoi.xml]
  - Marble  [marble.xml]
  - Procedural Fire  [fire.xml]
  - Aurora  [aurora.xml]

Retro and Analog (6)
  - Film Grain  [film_grain.xml]
  - Sepia Tone  [sepia.xml]
  - Retro Fade  [retro_fade.xml]
  - Chromatic Aberration  [chromatic.xml]
  - Vaporwave  [vaporwave.xml]
  - Super 8  [super8.xml]

3D and Depth (6)
  - Parallax Depth  [parallax.xml]
  - Height Relief  [relief.xml]
  - Depth Fog  [depth_fog.xml]
  - Anaglyph 3D  [anaglyph.xml]
  - Perspective Warp  [perspective.xml]
  - Voxel Look  [voxel.xml]

HOW TO USE
----------
See HOW-TO-INSTALL.txt.

Every file is plain XML + GLSL. Open one in any text editor,
change the numbers, and re-import. That is the whole workflow.

STRONG PRO EXAMPLES (9)
----------------------
One aggressive example per category, sorted first in the website library.

  Colour & Grade    - Cinematic Punch Pro    [cinematic_punch.xml]
  Blur & Focus      - Radial Rush Pro       [radial_rush.xml]
  Distort & Warp    - Liquid Rupture Pro    [liquid_rupture.xml]
  Glitch & Digital  - Data Collapse Pro     [data_collapse.xml]
  Light & Glow      - Solar Flare Pro       [solar_flare.xml]
  Stylize & Art     - Poster Impact Pro     [poster_impact.xml]
  Procedural        - Energy Storm Pro      [energy_storm.xml]
  Retro & Analog    - Tape Trauma Pro       [tape_trauma.xml]
  3D & Depth        - Holo Depth Pro        [holo_depth.xml]
